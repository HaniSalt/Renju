package renju;

public enum Stone {
    EMPTY, BLACK, WHITE
}